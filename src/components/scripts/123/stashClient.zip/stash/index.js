

mp.events.add("stash.show", (name, cost, data) => {
    if (mp.game.ui.isPauseMenuActive()) return;
    mp.callCEFV(`roulette.setData('${name}', ${cost}, '${JSON.stringify(data)}')`);
    mp.callCEFV(`roulette.setState(true)`);
    //mp.busy.add('opencase', false);
});
mp.events.add("stash.close", () => {
    mp.callCEFV(`roulette.setState(false)`);
    // mp.busy.remove('opencase');
});
mp.events.add("stash.items.show", (prizes) => {
    const items = [];

    prizes.forEach(prize => {
        items.push({
            id: prize.id,
            text: prize.name,
        });
    });
    items.push({ text: 'Закрыть' });

    mp.callCEFV(`selectMenu.setItems("stashShowItems", ${JSON.stringify(items)});`)
    mp.events.call("selectMenu.show", "stashShowItems");
});

// mp.keys.bind(0x1B, true, () => {
//     closeCase();
// });
function closeCase() {
    mp.callCEFV(`roulette.setState(false)`);
    //mp.busy.remove('opencase');
}